
.. Copyright BigchainDB GmbH and BigchainDB contributors
   SPDX-License-Identifier: (Apache-2.0 AND CC-BY-4.0)
   Code is Apache-2.0 and docs are CC-BY-4.0

Develop & Test BigchainDB Server
================================

If you'd like to help develop and test *BigchainDB Server*,
then see `the section about that in the docs about contributing to BigchainDB 
<https://docs.bigchaindb.com/projects/contributing/en/latest/dev-setup-coding-and-contribution-process/index.html>`_.
