
.. Copyright BigchainDB GmbH and BigchainDB contributors
   SPDX-License-Identifier: (Apache-2.0 AND CC-BY-4.0)
   Code is Apache-2.0 and docs are CC-BY-4.0

######################
Command Line Interface
######################

.. automodule:: bigchaindb.commands
    :special-members: __init__


:mod:`bigchaindb.commands.bigchaindb`
-------------------------------------

.. automodule:: bigchaindb.commands.bigchaindb


:mod:`bigchaindb.commands.utils`
--------------------------------

.. automodule:: bigchaindb.commands.utils
