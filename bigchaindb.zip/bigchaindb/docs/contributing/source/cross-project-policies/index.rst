
.. Copyright BigchainDB GmbH and BigchainDB contributors
   SPDX-License-Identifier: (Apache-2.0 AND CC-BY-4.0)
   Code is Apache-2.0 and docs are CC-BY-4.0

Policies
========


.. toctree::
   :maxdepth: 1

   code-of-conduct
   python-style-guide
   JavaScript Style Guide <https://github.com/ascribe/javascript>
   release-process
   